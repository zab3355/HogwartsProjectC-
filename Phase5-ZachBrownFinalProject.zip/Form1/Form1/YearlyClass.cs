﻿/************
 * author: Zach Brown
 * date: 2/11/2018
 * assignment: Phase 3 : Project 1
 * professor: Eric Baker
 * course: IGME 201
 * filename: Form1.cs
 * description: A program which has the ability to save, load, and clear data. This is programmed specifically for reading the 
 * students and detention programs, however, this program can read any type of JSON file. The data from the students and detention C# files are
 * places into a table on form1.
 ***********/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form1
{
    public class YearlyClass
    {
        public YearlyClass()
        {

        }

        public int Year()
        {

        }
    }
}
